import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

DB_NAME = 'kesenjangan_gender.db'

# ---------------- Database Setup ------------------
def connect_db():
    conn = sqlite3.connect(DB_NAME)
    return conn

def create_tables():
    print("Membuat tabel...")
    conn = connect_db()
    cur = conn.cursor()
    # ... (kode untuk membuat tabel)
    print("Tabel dibuat.")


def create_tables():
    conn = connect_db()
    cur = conn.cursor()
    # Tabel Jenis Laporan (Report Types)
    cur.execute('''
        CREATE TABLE IF NOT EXISTS ReportTypes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE
        )
    ''')
    # Tabel Layanan Hukum
    cur.execute('''
        CREATE TABLE IF NOT EXISTS LegalServices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            contact TEXT NOT NULL,
            location TEXT,
            service_type TEXT
        )
    ''')
    # Tabel Laporan Kekerasan Gender
    cur.execute('''
        CREATE TABLE IF NOT EXISTS Reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_type_id INTEGER NOT NULL,
            legal_service_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(report_type_id) REFERENCES ReportTypes(id),
            FOREIGN KEY(legal_service_id) REFERENCES LegalServices(id)
        )
    ''')

    # Insert default report types jika belum ada
    cur.execute('SELECT COUNT(*) FROM ReportTypes')
    count = cur.fetchone()[0]
    if count == 0:
        default_types = ['Kekerasan fisik', 'Kekerasan psikologis', 'Diskriminasi', 'Pelecehan seksual', 'Lainnya']
        cur.executemany('INSERT INTO ReportTypes (name) VALUES (?)', [(t,) for t in default_types])

    # Insert default legal services jika belum ada
    cur.execute('SELECT COUNT(*) FROM LegalServices')
    count_svc = cur.fetchone()[0]
    if count_svc == 0:
        default_services = [
            ('LBH Perempuan', '021-12345678', 'Jakarta', 'Bantuan Hukum'),
            ('Yayasan Perlindungan Perempuan', '021-87654321', 'Bandung', 'Konseling'),
            ('Klinik Psikologi Komunitas', '022-33344455', 'Surabaya', 'Psikolog'),
            ('Hotline Kekerasan Gender', '0800-123-456', 'Nasional', 'Darurat'),
        ]
        cur.executemany('INSERT INTO LegalServices (name, contact, location, service_type) VALUES (?,?,?,?)', default_services)

    conn.commit()
    conn.close()



# ---------------- Database Operations ------------------
def add_report(report_type_id, legal_service_id, status):
    conn = connect_db()
    cur = conn.cursor()
    created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cur.execute('''
        INSERT INTO Reports (report_type_id, legal_service_id, status, created_at)
        VALUES (?, ?, ?, ?)
    ''', (report_type_id, legal_service_id, status, created_at))
    conn.commit()
    conn.close()

def update_report_status(report_id, new_status):
    conn = connect_db()
    cur = conn.cursor()
    cur.execute('UPDATE Reports SET status = ? WHERE id = ?', (new_status, report_id))
    conn.commit()
    conn.close()

def delete_report(report_id):
    conn = connect_db()
    cur = conn.cursor()
    cur.execute('DELETE FROM Reports WHERE id = ?', (report_id,))
    conn.commit()
    conn.close()

def get_report_types():
    conn = connect_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM ReportTypes ORDER BY name')
    rows = cur.fetchall()
    conn.close()
    return rows

def get_legal_services():
    conn = connect_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM LegalServices ORDER BY name')
    rows = cur.fetchall()
    conn.close()
    return rows

def get_reports(filter_status=None, sort_by='created_at', ascending=False):
    conn = connect_db()
    cur = conn.cursor()
    query = '''
        SELECT Reports.id, ReportTypes.name, LegalServices.name, Reports.status, Reports.created_at
        FROM Reports
        JOIN ReportTypes ON Reports.report_type_id = ReportTypes.id
        JOIN LegalServices ON Reports.legal_service_id = LegalServices.id
    '''
    params = []
    if filter_status and filter_status != "All":
        query += ' WHERE Reports.status = ?'
        params.append(filter_status)
    if sort_by in ['created_at', 'status']:
        order = 'ASC' if ascending else 'DESC'
        query += f' ORDER BY Reports.{sort_by} {order}'
    cur.execute(query, params)
    rows = cur.fetchall()
    conn.close()
    return rows

def report_statistics():
    conn = connect_db()
    cur = conn.cursor()
    cur.execute('SELECT status, COUNT(*) FROM Reports GROUP BY status')
    stats = cur.fetchall()
    conn.close()
    return stats


# ---------------- GUI Application ------------------
class KesenjanganGenderApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Aplikasi Pelaporan Kesenjangan Gender")
        self.geometry("1000x700")
        self.configure(bg="#f9f9f9")
        self.create_widgets()
        create_tables()
        self.populate_report_types()
        self.populate_legal_services_dropdown()
        self.populate_reports()
        self.selected_report_id = None

    def create_widgets(self):
        # Title
        title = tk.Label(self, text="Aplikasi Pelaporan Kekerasan Gender", font=("Helvetica", 18, "bold"),
                         bg="#f9f9f9", fg="#333")
        title.pack(pady=10)

        # Tabs
        self.tab_control = ttk.Notebook(self)
        self.tab_control.pack(expand=1, fill='both')

        self.tab_reports = ttk.Frame(self.tab_control)
        self.tab_stats = ttk.Frame(self.tab_control)

        self.tab_control.add(self.tab_reports, text='Laporan Kasus')
        self.tab_control.add(self.tab_stats, text='Statistik')

        self.create_reports_tab()
        self.create_stats_tab()

    # --------- Reports Tab ---------
    def create_reports_tab(self):
        frame = self.tab_reports
        # Form frame
        form_frame = tk.LabelFrame(frame, text="Tambah / Update Laporan", padx=10, pady=10)
        form_frame.pack(fill='x', padx=10, pady=10)

        # Dropdown untuk Pilih Jenis Laporan
        tk.Label(form_frame, text="Jenis Laporan:", font=("Helvetica", 12)).grid(row=0, column=0, sticky='w')
        self.report_type_var = tk.StringVar()
        self.report_type_dropdown = ttk.Combobox(form_frame, textvariable=self.report_type_var, width=50,
                                                 state='readonly')
        self.report_type_dropdown.grid(row=0, column=1, pady=5, padx=5)

        # Dropdown untuk Pilih Layanan Hukum
        tk.Label(form_frame, text="Pilih Layanan Hukum:", font=("Helvetica", 12)).grid(row=1, column=0, sticky='w')
        self.legal_service_var = tk.StringVar()
        self.legal_service_dropdown = ttk.Combobox(form_frame, textvariable=self.legal_service_var, width=50,
                                                   state='readonly')
        self.legal_service_dropdown.grid(row=1, column=1, pady=5, padx=5)

        # Status dropdown
        tk.Label(form_frame, text="Status:", font=("Helvetica", 12)).grid(row=2, column=0, sticky='w')
        self.status_var = tk.StringVar()
        self.status_combo = ttk.Combobox(form_frame, textvariable=self.status_var,
                                         values=["baru", "ditangani", "selesai"], state='readonly', width=20)
        self.status_combo.grid(row=2, column=1, pady=5, sticky='w')
        self.status_combo.current(0)

        # Buttons
        btn_frame = tk.Frame(form_frame)
        btn_frame.grid(row=3, column=1, pady=10, sticky='w')
        self.btn_add = tk.Button(btn_frame, text="Tambah Laporan", bg="#28a745", fg="white", command=self.add_report)
        self.btn_add.pack(side='left', padx=5)

        self.btn_update = tk.Button(btn_frame, text="Update Status", bg="#007bff", fg="white",
                                    command=self.update_report, state='disabled')
        self.btn_update.pack(side='left', padx=5)

        self.btn_delete = tk.Button(btn_frame, text="Hapus Laporan", bg="#dc3545", fg="white",
                                    command=self.delete_report, state='disabled')
        self.btn_delete.pack(side='left', padx=5)

        # Filter & Sort frame
        filter_frame = tk.Frame(frame)
        filter_frame.pack(fill='x', padx=10)

        tk.Label(filter_frame, text="Filter Status:").pack(side='left')
        self.filter_status_var = tk.StringVar(value="All")
        self.filter_status_combo = ttk.Combobox(filter_frame, textvariable=self.filter_status_var,
                                                values=["All", "baru", "ditangani", "selesai"], state='readonly', width=15)
        self.filter_status_combo.pack(side='left', padx=5)
        self.filter_status_combo.bind("<<ComboboxSelected>>", lambda e: self.populate_reports())

        tk.Label(filter_frame, text="Sort by:").pack(side='left', padx=(20, 0))
        self.sort_by_var = tk.StringVar(value="created_at")
        self.sort_by_combo = ttk.Combobox(filter_frame, textvariable=self.sort_by_var,
                                          values=["created_at", "status"], state='readonly', width=15)
        self.sort_by_combo.pack(side='left', padx=5)
        self.sort_by_combo.bind("<<ComboboxSelected>>", lambda e: self.populate_reports())

        tk.Label(filter_frame, text="Ascending:").pack(side='left', padx=(20, 0))
        self.ascending_var = tk.BooleanVar(value=False)
        self.ascending_check = ttk.Checkbutton(filter_frame, variable=self.ascending_var, command=self.populate_reports)
        self.ascending_check.pack(side='left', padx=5)

        # Table frame
        table_frame = tk.Frame(frame)
        table_frame.pack(fill='both', expand=True, padx=10, pady=10)

        columns = ("id", "report_type", "legal_service", "status", "created_at")
        self.tree_reports = ttk.Treeview(table_frame, columns=columns, show='headings')
        self.tree_reports.heading("id", text="ID")
        self.tree_reports.column("id", width=50, anchor='center')
        self.tree_reports.heading("report_type", text="Jenis Laporan")
        self.tree_reports.column("report_type", width=230)
        self.tree_reports.heading("legal_service", text="Layanan Hukum")
        self.tree_reports.column("legal_service", width=230)
        self.tree_reports.heading("status", text="Status")
        self.tree_reports.column("status", width=100, anchor='center')
        self.tree_reports.heading("created_at", text="Tanggal")
        self.tree_reports.column("created_at", width=150, anchor='center')
        self.tree_reports.pack(fill='both', expand=True)

        self.tree_reports.bind("<<TreeviewSelect>>", self.on_report_select)

    def populate_report_types(self):
        types = get_report_types()
        self.report_types_map = {name: rid for rid, name in types}
        self.report_type_dropdown['values'] = list(self.report_types_map.keys())
        if types:
            self.report_type_dropdown.current(0)

    def populate_legal_services_dropdown(self):
        services = get_legal_services()
        self.legal_services_map = {name: sid for sid, name, _, _, _ in services}
        self.legal_service_dropdown['values'] = list(self.legal_services_map.keys())
        if services:
            self.legal_service_dropdown.current(0)

    def populate_reports(self):
        for row in self.tree_reports.get_children():
            self.tree_reports.delete(row)
        filter_status = self.filter_status_var.get()
        sort_by = self.sort_by_var.get()
        ascending = self.ascending_var.get()
        reports = get_reports(filter_status=filter_status, sort_by=sort_by, ascending=ascending)
        for rep in reports:
            self.tree_reports.insert("", 'end', values=rep)
        self.btn_update.config(state='disabled')
        self.btn_delete.config(state='disabled')
        self.selected_report_id = None
        # Reset form
        if self.report_type_dropdown['values']:
            self.report_type_dropdown.current(0)
        if self.legal_service_dropdown['values']:
            self.legal_service_dropdown.current(0)
        self.status_combo.current(0)

    def on_report_select(self, event):
        selected = self.tree_reports.selection()
        if selected:
            item = self.tree_reports.item(selected[0])
            values = item['values']
            self.selected_report_id = values[0]

            # Set dropdown report type
            report_type = values[1]
            if report_type in self.report_types_map:
                idx = list(self.report_types_map.keys()).index(report_type)
                self.report_type_dropdown.current(idx)

            # Set dropdown legal service
            legal_service = values[2]
            if legal_service in self.legal_services_map:
                idx = list(self.legal_services_map.keys()).index(legal_service)
                self.legal_service_dropdown.current(idx)

            # Set status
            status = values[3]
            status_values = ["baru", "ditangani", "selesai"]
            try:
                status_idx = status_values.index(status)
            except ValueError:
                status_idx = 0
            self.status_combo.current(status_idx)

            self.btn_update.config(state='normal')
            self.btn_delete.config(state='normal')

    def add_report(self):
        report_type_name = self.report_type_var.get()
        legal_service_name = self.legal_service_var.get()
        status = self.status_var.get()
        if not report_type_name or report_type_name not in self.report_types_map:
            messagebox.showwarning("Peringatan", "Jenis laporan harus dipilih")
            return
        if not legal_service_name or legal_service_name not in self.legal_services_map:
            messagebox.showwarning("Peringatan", "Layanan hukum harus dipilih")
            return
        add_report(self.report_types_map[report_type_name], self.legal_services_map[legal_service_name], status)
        messagebox.showinfo("Sukses", "Laporan berhasil ditambahkan")
        self.populate_reports()

    def update_report(self):
        if not self.selected_report_id:
            messagebox.showwarning("Peringatan", "Pilih laporan untuk diupdate")
            return
        new_status = self.status_var.get()
        update_report_status(self.selected_report_id, new_status)
        messagebox.showinfo("Sukses", "Status laporan berhasil diperbarui")
        self.populate_reports()

    def delete_report(self):
        if not self.selected_report_id:
            messagebox.showwarning("Peringatan", "Pilih laporan untuk dihapus")
            return
        answer = messagebox.askyesno("Konfirmasi", "Apakah Anda yakin ingin menghapus laporan ini?")
        if answer:
            delete_report(self.selected_report_id)
            messagebox.showinfo("Sukses", "Laporan berhasil dihapus")
            self.populate_reports()

    # --------- Statistik Tab ---------
    def create_stats_tab(self):
        frame = self.tab_stats

        info_label = tk.Label(frame, text="Statistik Jumlah Laporan Berdasarkan Status", font=("Helvetica", 14))
        info_label.pack(pady=10)

        self.stats_canvas_frame = tk.Frame(frame)
        self.stats_canvas_frame.pack(fill='both', expand=True, padx=20, pady=10)

        self.btn_refresh_stats = tk.Button(frame, text="Refresh Statistik", bg="#007bff", fg="white",
                                           command=self.draw_statistics)
        self.btn_refresh_stats.pack(pady=10)

        self.draw_statistics()

    def draw_statistics(self):
        for widget in self.stats_canvas_frame.winfo_children():
            widget.destroy()

        stats = report_statistics()
        if not stats:
            label = tk.Label(self.stats_canvas_frame, text="Belum ada data laporan.", font=("Helvetica", 12))
            label.pack()
            return

        statuses = [item[0] for item in stats]
        counts = [item[1] for item in stats]

        fig, ax = plt.subplots(figsize=(6, 4))
        colors = ['#FF6F61', '#FFA500', '#4CAF50']  # warna menarik
        ax.bar(statuses, counts, color=colors[:len(statuses)])
        ax.set_title('Jumlah Laporan Berdasarkan Status')
        ax.set_xlabel('Status')
        ax.set_ylabel('Jumlah Laporan')
        ax.grid(axis='y', linestyle='--', alpha=0.7)
        for i, v in enumerate(counts):
            ax.text(i, v + 0.1, str(v), ha='center', fontweight='bold')

        canvas = FigureCanvasTkAgg(fig, master=self.stats_canvas_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill='both', expand=True)


# --------------- Main Program ---------------
if __name__ == "__main__":
    app = KesenjanganGenderApp()
    app.mainloop()

